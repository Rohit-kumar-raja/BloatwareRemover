package com.company;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

public class gui extends JFrame implements ActionListener,KeyListener {
    String searchdata = "c";
    Process process;
    JButton connect;
    public JList<String> list;
    JTextArea label;
    JPanel panel;
    JButton Uninstall;
    ArrayList<String> arrayList;
    JButton SearchButton;
    JTextField Searchfield;
    JLabel About;

    DefaultListModel<String> Package_name = new DefaultListModel<>();

    gui() {

        //this is the Boader style
        Border margin = new EmptyBorder(5, 15, 5, 15);
        Border line = new LineBorder(Color.BLACK);
        Border compound = new CompoundBorder(line, margin);
        //this is the connect button
        connect = new JButton("Connect");
        connect.setBounds(740, 98, 100, 23);
        connect.setBackground(Color.getHSBColor(0.288f, 0.481f, 0.592f));
        connect.setBorder(compound);
        connect.addActionListener(this);
        add(connect);
        //Label here
        label = new JTextArea();
        label.setBorder(compound);
        label.setEditable(false);
        label.setBounds(110, 98, 550, 33);
        label.setFont(label.getFont().deriveFont(15.6f));
        add(label);
        //Jlist here
        panel = new JPanel(new BorderLayout());
        panel.setVisible(false);
        list = new JList<String>(Package_name);
        // panel.setBackground(Color.darkGray);
        panel.setBounds(50, 200, 700, 300);
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setViewportView(list);
        panel.add(scrollPane);
        add(panel);
        //Uninstall Button
        Uninstall = new JButton("Uninstall");
        Uninstall.setBounds(300, 550, 100, 22);
        Uninstall.setBackground(Color.getHSBColor(0.288f, 0.481f, 0.592f));
        Uninstall.addActionListener(this);
        Uninstall.setVisible(false);
        add(Uninstall);
        //here is the text field for serching text
        Searchfield = new JTextField();
        Searchfield.setBounds(50, 176, 700, 25);
        Searchfield.addActionListener(this);
        Searchfield.setToolTipText("Serch here any apps");
        Searchfield.setVisible(false);
        Searchfield.setBackground(Color.white);
        add(Searchfield);
        //search button for texfield
        SearchButton = new JButton("Search");
        SearchButton.setBounds(745, 176, 100, 25);
        SearchButton.setBackground(Color.getHSBColor(0.288f, 0.481f, 0.592f));
        SearchButton.addActionListener(this);
        SearchButton.setVisible(false);
        add(SearchButton);
        //this is the about section
        String text="About";
        About=new JLabel("About");
        About.setForeground(Color.getHSBColor(0.288f, 0.481f, 0.592f));
        About.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    Desktop.getDesktop().browse(new URI("http://www.geekprocoder.com"));
                } catch (IOException | URISyntaxException e1) {
                    e1.printStackTrace();
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                About.setText(text);
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                About.setText("<html><a href=''>" + text + "</a></html>");
            }

        });
        About.setBounds(800,8,100,20);
        add(About);
        setTitle("Bloatware Remover");
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("icon.png")));
        //here i have seated the frame
        setSize(900, 700);
        getContentPane().setBackground(Color.darkGray);
        setLayout(null);
        setVisible(true);
    }


    public static void main(String[] args) {
        new gui();
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        if (actionEvent.getSource() == connect) {
            adbdevices();
            checkcCondition();
        }


        if (actionEvent.getSource() == Uninstall) {
             uninstall(list);
        }
        if (actionEvent.getSource() == SearchButton) {
            SerchdataformTextfield();
        }

    }


    //this is the connetion method in this method
    // devices are connected
    public void adbdevices() {
        String data;


        arrayList = new ArrayList<String>();
        try {
            process = Runtime.getRuntime().exec("adb devices");
            // System.out.println("");
            BufferedReader bef = new BufferedReader(new InputStreamReader(process.getInputStream()));
            while ((data = bef.readLine()) != null) {
                System.out.println(data);

                arrayList.add(data);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //this method has listed the packages here
    public void listpackege() {
        try {
            label.setText(String.valueOf(arrayList));
            System.out.println("this is search data" + searchdata);
            process = Runtime.getRuntime().exec(" adb shell pm list packages -e | grep '" + searchdata + "'");
            String[] s = new String[0];
            String data;
            BufferedReader listofdata = new BufferedReader(new InputStreamReader(process.getInputStream()));
            while ((data = listofdata.readLine()) != null) {

                s = data.split("package:");
                // System.out.println(s);
                for (int i = 0; i < s.length; i++) {
                    Package_name.addElement(s[i]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void checkcCondition() {
        if (arrayList.size() <= 2) {
            JOptionPane.showMessageDialog(this, "Device is not Connected");
            arrayList.clear();
            label.setText("");
            panel.setVisible(false);
            Uninstall.setVisible(false);
            Searchfield.setVisible(false);
            SearchButton.setVisible(false);

        } else if (arrayList.size() >= 4) {
            JOptionPane.showMessageDialog(this, "More Devices conneted");
            arrayList.clear();
            label.setText("");
            panel.setVisible(false);
            Uninstall.setVisible(false);
            Searchfield.setVisible(false);
            SearchButton.setVisible(false);

        } else {
            panel.setVisible(true);
            Uninstall.setVisible(true);
            Searchfield.setVisible(true);
            SearchButton.setVisible(true);
            listpackege();
        }
    }


    public void uninstall(JList < String > list) {
        List listdata;
        Process process;


            listdata = list.getSelectedValuesList();
            if (listdata.size()==0){
                JOptionPane.showMessageDialog(this,"please select any apps");
            }
            else{
            try {
                for (int i = 0; i < listdata.size(); i++) {
                    System.out.println(listdata.get(i));
                    process = Runtime.getRuntime().exec("adb shell pm uninstall -k --user 0 " + listdata.get(i));
                    // System.out.println("");
                    BufferedReader bef = new BufferedReader(new InputStreamReader(process.getInputStream()));
                    String data;
                    while ((data = bef.readLine()) != null) {
                        System.out.println(data);
                    }
                    if (data == null) {
                        JOptionPane.showMessageDialog(this, "Uninstalled Sucessfully");
                        Package_name.clear();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }}
        @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode()==KeyEvent.VK_0){
            System.out.println("Enter key is pressed");
        SerchdataformTextfield();
    }}
    @Override
    public void keyReleased(KeyEvent e) {
        SerchdataformTextfield();
    }
    @Override
    public void keyTyped(KeyEvent e) {
        SerchdataformTextfield();
    }

    private void SerchdataformTextfield() {
        searchdata = Searchfield.getText();
        System.out.println(searchdata);
        Package_name.clear();
        adbdevices();
        checkcCondition();

    }

}

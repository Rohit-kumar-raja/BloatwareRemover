package com.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Main {


    Process process;
    String data;
    Main() throws IOException {
        ArrayList<String> arrayList = new ArrayList<String>();
        process=Runtime.getRuntime().exec("adb shell");
        // System.out.println("");
        BufferedReader bef=new BufferedReader(new InputStreamReader(process.getInputStream()));
        while((data=bef.readLine()) !=null){
            System.out.println(data);
            arrayList.add(data);
        }
        System.out.println(arrayList);
    }
    public static void main(String[] args) throws IOException {
        new Main();
    }
}
